;---------------------------------------------------------------------------;
;									    ;
;                      S45 & S45Q    R E L E A S E    N O T E               ;
;									    ;
;---------------------------------------------------------------------------;


BIOS Version: S45_3A25	Release Date: 10/05/2009	Checksum: 3AA39613
Update BootBlock: YES	Clear CMOS: NO

Flash Utility:		AFUDOS v4.21
VGA BIOS:		AST2000 v.0.88.04
SCSI BIOS:		N/A
PXE ROM:		Intel(R) Boot Agent GE v1.3.00
BMC F/W:		S45 	Generic - 2.20 
			    	Amazon  - 2.25
			S45Q	Generic - 1.80
				Amazon  - 1.85
Memory Reference Code:	MRC v1.3


Change History - From BIOS version S45_3A24 to S45_3A25:
	(01) Improvement: 	Supported HDD size up to 4294.9T.
	(02) Parse OS Boot(Sensor Type 1Fh) and OS Stop/Shutdown(Sensor Type 20h) SEL completely.
	(03) Correct CPU definition in SMBIOS type 04h
	(04) Show AC Power Recovery Delay help msg
	(05) Fixed "All Event Logging Disabled" parsing issue
	(06) Modify the string of Flash Successfully
	(07) Support Winbond W25Q32 4M SPI flash.
	(08) Add PERC6/I for identifying and sending to BMC.

;---------------------------------------------------------------------------;
BIOS Version: S45_3A24	Release Date: 06/05/2009	Checksum: 3AA281D5
Update BootBlock: YES	Clear CMOS: NO

Flash Utility:		AFUDOS v4.21
VGA BIOS:		AST2000 v.0.88.04
SCSI BIOS:		N/A
PXE ROM:		Intel(R) Boot Agent GE v1.3.00
BMC F/W:		S45 	Generic - 2.20 
			    	Amazon  - 2.25
			S45Q	Generic - 1.80
				Amazon  - 1.85
Memory Reference Code:	MRC v1.3


Change History - From BIOS version S45_3A23 to S45_3A24:
	(01) Fixed the NIC2 description is incorrect in BIOS(defect 109890)
	(02) Modify the description of NIC2 in SMBIOS Type 0Ah(defect 110059)
	(03) Prevent RBU can't work properly in Redhat XEN during warmboot
	(04) Shade Frequency Ratio item when Speedstep is disabled(defect 110148)
	(05) Added dell low power mode help message.
	(06) Modify Set_LAN_Configuration_Help message from Spec 1.5 to Spec 2.0
	(07) Get the value of version from FRU in SMBIOS Type 02h and Type 03h

;---------------------------------------------------------------------------;
BIOS Version: S45_3A23	Release Date: 05/11/2009	Checksum: 3AA24AFE
Update BootBlock: YES	Clear CMOS: NO

Flash Utility:		AFUDOS v4.21
VGA BIOS:		AST2000 v.0.88.04
SCSI BIOS:		N/A
PXE ROM:		Intel(R) Boot Agent GE v1.3.00
BMC F/W:		S45 	Generic - 2.20 
			    	Amazon  - 2.25
			S45Q	Generic - 1.80
				Amazon  - 1.85
Memory Reference Code:	MRC v1.3


Change History - From BIOS version S45_3A22 to S45_3A23:
	(01) Set NIC1 disable with SB.
	(02) Set token "HOOK_INT10_IN_OPTION_ROM" = OFF
	(03) Remove the unsupported ratio in Frequency Ratio
	(04) Update Intel RAID for SATA optionROM to v8.8.0.1009 from v7.5.0.1014
	(05) Check Record type(SEL Event Record Byte3) before parsing SEL.
	(06) Parse Watchdog SEL completely
	(07) Do Error-Proof for AC stagger setting
	(08) Set C2E and C4E to enable
	(09) Update SMBIOS module from 8.00.08_SMB-3.1.02_CORE_RC22 to 8.00.08_SMB-3.1.02_CORE_RC29
	(10) Get type 02h asset tag from FRU(same with type 03h asset tag)
	(11) Set timer to legacy timer after warmboot(defect 109782)

;---------------------------------------------------------------------------;
BIOS Version: S45_3A22	Release Date: 02/26/2009	Checksum: 3A591CE5
Update BootBlock: YES	Clear CMOS: NO

Flash Utility:		AFUDOS v4.21
VGA BIOS:		AST2000 v.0.88.04
SCSI BIOS:		N/A
PXE ROM:		Intel(R) Boot Agent GE v1.3.00
BMC F/W:		S45 	Generic - 1.50 
			    	Amazon  - 1.55
			S45Q	Generic - 1.30
				Amazon  - 1.35
Memory Reference Code:	MRC v1.3


Change History - From BIOS version S45_3A21 to S45_3A22:
	(01) Add Dell SMBIOS D4 tokens structure.(for power saving)
	   * 01D6h   TOKEN_MEM_DCLK_DIS      Setting the option to disabled allow memory to run full speed
           * 01D7h   TOKEN_MEM_DCLK_EN       Setting the option to enabled will down-clock the memory to conserve power.
	(02) Fixed RBU can't work properly in linux when Console redirection enabled
	   * Disable HPET before warmboot
	   * Update the warmboot module
           * Update serial redirection module to beta9
	(03) Fixed COM1 disable, COM2 enable and Remote access enable would hang on NIC optionROM.
	(04) Update INTEL P4 CPU Module from 8.00.12_CPU-P4_3F.11 to 8.00.12_CPU-P4_3F.14
	   * For Intel REF.NO.380903, Wolfdale BIOS specification update rev0.8 section1.2
	(05) Implement Service Processor Management Interface(SPMI) Description Table and ACPI Control Methods.
	(06) Fixed BMC IP address will be changed by itself.

;---------------------------------------------------------------------------;
BIOS Version: S45_3A21	Release Date: 02/04/2009	Checksum: 3A5C789F
Update BootBlock: YES	Clear CMOS: NO

Flash Utility:		AFUDOS v4.21
VGA BIOS:		AST2000 v.0.88.04
SCSI BIOS:		N/A
PXE ROM:		Intel(R) Boot Agent GE v1.3.00
BMC F/W:		S45 	Generic - 1.50 
			    	Amazon  - 1.55
			S45Q	Generic - 1.30
				Amazon  - 1.35
Memory Reference Code:	MRC v1.3


Change History - From BIOS version S45_3A20 to S45_3A21:
	(01) Clear the bit 6 and bit 7 in CMOS 0Eh register before store the battery failed status.

;---------------------------------------------------------------------------;
BIOS Version: S45_3A20	Release Date: 01/21/2009	Checksum: 3A5C992D
Update BootBlock: YES	Clear CMOS: NO

Flash Utility:		AFUDOS v4.21
VGA BIOS:		AST2000 v.0.88.04
SCSI BIOS:		N/A
PXE ROM:		Intel(R) Boot Agent GE v1.3.00
BMC F/W:		S45 	Generic - 1.50 
			    	Amazon  - 1.55
			S45Q	Generic - 1.30
				Amazon  - 1.35
Memory Reference Code:	MRC v1.3


Change History - From BIOS version S45S_101 to S45_3A20:
	(01) Change the BIOS name from S45S_101 to S45_3A20.

;---------------------------------------------------------------------------;
BIOS Version: S45S_101	Release Date: 12/31/2008	Checksum: 3A5B9803
Update BootBlock: YES	Clear CMOS: NO

Flash Utility:		AFUDOS v4.21
VGA BIOS:		AST2000 v.0.88.04
SCSI BIOS:		N/A
PXE ROM:		Intel(R) Boot Agent GE v1.3.00
BMC F/W:		S45 	Generic - 1.50 
			    	Amazon  - 1.55
			S45Q	Generic - 1.30
				Amazon  - 1.35
Memory Reference Code:	MRC v1.3


Change History - From BIOS version S45S_100 to S45S_101:
	(01) Fixed PXE install from NIC2 this issue.
	(02) Get UUID from 'Get Device Guid' instead of specific FRU offset.
	(03) Fixed COM1 and COM2 disable would hang on debug port 37h
	(04) Fixed COM1 disable, COM2 enable and Remote access enable 
	     would hang on debug port 37h
	(05) Fixed the CPU ratio disply in BIOS setup menu.
	(06) Fixed the ratio setting if CPU only support one ratio

;---------------------------------------------------------------------------;
BIOS Version: S45S_100	Release Date: 12/18/2008	Checksum: 3A5BA59B
Update BootBlock: YES	Clear CMOS: NO

Flash Utility:		AFUDOS v4.21
VGA BIOS:		AST2000 v.0.88.04
SCSI BIOS:		N/A
PXE ROM:		Intel(R) Boot Agent GE v1.3.00
BMC F/W:		S45 	Generic - 1.51 
			    	Amazon  - 1.56
			S45Q	Generic - 1.30
				Amazon  - 1.35
Memory Reference Code:	MRC v1.3


Change History - From BIOS version S45Q3A05 to S45S_100:
	(01) Identify both 1U and 2U riser card in SMBIOS(for merge S45 & S45Q)
	(02) Fixed the console(include SOL) can't sync with local screen in DOS.
	(03) Fixed BIOS didn't clear H_BUSY(Host Busy) bit after using BT interface issue.
	(04) Solved XOFF(CTRL + S) conflict with NIC OptionROM's short key problem.
	(05) Add Frequancy Ratio function(Magic VID)
	(06) Disable Unused Devices
	(07) Disable Unused CLOCK
	(08) Define 1U or 2U case by jumper J5B1

;---------------------------------------------------------------------------;
BIOS Version: 3A05	Release Date: 12/02/2008	Checksum: 3A5D81CF
Update BootBlock: YES	Clear CMOS: NO

Flash Utility:		AFUDOS v4.21
VGA BIOS:		AST2000 v.0.88.04
SCSI BIOS:		N/A
PXE ROM:		Intel(R) Boot Agent GE v1.3.00
BMC F/W:		1.30
Memory Reference Code:	MRC v1.3

Change History - From BIOS version S45T3A04 to S45Q3A05:
	(01) Fixed RBU can't work properly in linux when Console redirection enabled

;---------------------------------------------------------------------------;
BIOS Version: 3A04	Release Date: 11/14/2008	Checksum: 3A5D6BA3
Update BootBlock: YES	Clear CMOS: NO

Flash Utility:		AFUDOS v4.21
VGA BIOS:		AST2000 v.0.88.04
SCSI BIOS:		N/A
PXE ROM:		Intel(R) Boot Agent GE v1.3.00
BMC F/W:		1.20
Memory Reference Code:	MRC v1.3

Change History - From BIOS version S45T3A03 to S45Q3A04:
	(01) Monitor AFTERG3_EN bit on AC cycle.
	(02) Scan RPK over 4G memory during RBU.
	(03) Update option rom of AST2000 from v.0.88.03 to v.0.88.04
	
====================
INTEL PROCESSOR MICORCODE REVISIONS
=======================
SRV_P_75.exe
----------------+-------------------------------+------------------
Filename        | Description                   | Stepping(s)      
----------------+-------------------------------+------------------
M441067AA07.TXT | Assembly format, Revision A07 | E-0 (Harpertown) 

SRV_P_71.exe
----------------+-------------------------------+------------------
Filename        | Description                   | Stepping(s)      
----------------+-------------------------------+------------------
M401067660C.TXT | Assembly format, Revision 60C | C-0 (Harpertown)
M041067660C.TXT | Assembly format, Revision 60C | C-0 (Wolfdale-DP)

SRV_P_69.exe
------------------------+---------------------------------------+----------------
Filename     		| Description                  		| Stepping(s)
------------------------+---------------------------------------+----------------
M046F6CD.TXT    	| Assembly format, Revision CD  	| B-2 (Woodcrest)
M406F769.TXT    	| Assembly format, Revision 69  	| B-3 (Clovertown)
M401067660B.TXT 	| Assembly format, Revision 60B 	| C-0 (Harpertown)     
M041067660B.TXT 	| Assembly format, Revision 60B 	| C-0 (Wolfdale-DP) 

SRV_P_66.exe
------------------------+---------------------------------------+----------------
Filename     		| Description                  		| Stepping(s)
------------------------+---------------------------------------+----------------
M046FBB7.TXT		| Assembly format, Revision B7		| G-0 (Woodcrest)
M406FBB7.TXT		| Assembly format, Revision B7		| G-0 (Clovertown)
------------------------+---------------------------------------+----------------

SRV_P_64.exe
------------------------+---------------------------------------+----------------
Filename     		| Description                  		| Stepping(s)
------------------------+---------------------------------------+----------------
M01F6402.TXT 		| Assembly format, Revision 02 		| C-1 (Dempsey)
M01F6508.TXT 		| Assembly format, Revision 08 		| D-0 (Dempsey)
------------------------+---------------------------------------+----------------
	
;---------------------------------------------------------------------------;
;				A P P E N D I X                             ;
;---------------------------------------------------------------------------;

A.1 How to run the utility under DOS

1.	Note the settings of the SETUP parameters.  Enter SETUP by hitting 
	the DEL key during boot up.  Write down the settings for each of 
	parameters. At the end of the BIOS update process you should set the 
	parameters to default values by hitting the F9 key, and then re-enter 
	these values you have written down.

2.	The method to flash BIOS.
	(1) Copy all of the following files into the same folder in Hard Drive
	    or bootable USB Disk Key in DOS :
	    F.bat
	    AFUDOS.exe
	    S59_xxxx.rom
	(2) Go to this folder to run F.bat and update finishes automatically.

***********************************************
***  AMI AFUDOS Flash Feature Details  ***
***********************************************
- AFUDOS.EXE V4.21
- This update processing takes 1 minute.  Never turn off the system during the 
  update processing. The following message appears when the update processing 
  is finished:

	- Botoblock checksum .... ok
	- Module checksums ...... ok
	- Erasing NCB ........... done
	- Writing NCB ........... done
	- Verifying NCB ......... done
	- Erasing flash ......... done
	- Writing flash ......... done
	- Verifying flash ....... done
	- Erasing BootBlock ..... done
	- Writing BootBlock ..... done
	- Verifying BootBlock ... done
	- Program ended normally.

  If the system does not restart, TURN THE POWER OFF, THEN ON.

AMI Firmware Update Utility - Version 4.21
Copyright (C)2004 American Megatrends, Inc.  All rights reserved.
Usage:
	AFUDOS <ROM File Name> [Option 1] [Option 2]...
	or
	AFUDOS <ROM File Name> <Command>
	or
	AFUDOS /M<Mac Address>
Commands:
	/O - Save current BIOS into file
	/U - Display ROM file's ROMID
Options:
	/P - Program main BIOS image
	/B - Program Boot Block
	/N - Program NVRAM
	/C - Destroy CMOS checksum
	/E - Program Embedded Controller Block
	/K - Program all non-critical blocks
	/Kn - Program n'th non-critical block only(n=0-7)
	/Q - Silent execution
	/REBOOT - Reboot after programming
	/X - Don't Check ROM ID
	/S - Display current system's ROMID
	/Ln - Load CMOS defaults:(n=0-3)
	      L0: Load current optimal
	      L1: Load current failsafe
	      L2: Load optimal from ROM file
	      L3: Load failsafe from ROM file
	/M - Update bootblock MAC address if it exists
	     Example: /M1234ABCD will update MAC to 1234ABCD
	/R - Preserve ALL SMBIOS structure during NVRAM programming
	/Rn - Preserve SMBIOS type N during NVRAM programming(n=1-255)
	      Example: Use '/R0 /R11' will preserve type 0 and 11 if they 
	      exists.

A.2 Recover the system BIOS:
   A.2.1. How to recover the BIOS:
	The system BIOS can be recovered via the floppy diskette containing
	BIOS image file AMIBOOT.ROM by pressing the hot key <Ctrl>-<Home>
	during POST (Power-On Self Test).
   A.2.2. How to create a recovery diskette:
	(1) Prepare a formatted floppy diskette.
	(2) Copy the BIOS ROM file to the root directory of the diskette and
	    rename it to AMIBOOT.ROM.
